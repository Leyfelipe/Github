--
-- File generated with SQLiteStudio v3.1.1 on dom out 29 10:09:48 2017
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: tb_fun
DROP TABLE IF EXISTS tb_fun;

CREATE TABLE tb_fun (
    id    INTEGER PRIMARY KEY AUTOINCREMENT
                  UNIQUE
                  NOT NULL,
    nome  VARCHAR NOT NULL,
    setor VARCHAR NOT NULL
);

INSERT INTO tb_fun (id, nome, setor) VALUES (1, 'Felipe', 'Gerente');
INSERT INTO tb_fun (id, nome, setor) VALUES (2, 'Maria', 'Frentista');
INSERT INTO tb_fun (id, nome, setor) VALUES (3, 'Jo�o', 'Frentista');

-- Table: tb_posto
DROP TABLE IF EXISTS tb_posto;

CREATE TABLE tb_posto (
    id          INTEGER PRIMARY KEY AUTOINCREMENT
                        UNIQUE
                        NOT NULL,
    data        VARCHAR NOT NULL,
    funcionario VARCHAR NOT NULL,
    tank        CHAR    NOT NULL,
    combustivel VARCHAR NOT NULL,
    val_din     DECIMAL,
    val_litro   DECIMAL NOT NULL
);

INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (8, '28/10/2017', 'Jo�o', 'B', '�leo Diesel', 4633, 820);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (9, '28/10/2017', 'Maria', 'B', 'Gasolina', '282,5', 50);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (10, '28/10/2017', 'Jo�o', 'A', 'Gasolina', 339, 60);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (11, '28/10/2017', 'Felipe', 'B', '�leo Diesel', '395,5', 70);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (12, '28/10/2017', 'Jo�o', 'A', '�leo Diesel', '395,5', 70);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (13, '28/10/2017', 'Maria', 'A', 'Gasolina', '5045,45', 893);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (14, '29/10/2017', 'Maria', 'A', '�leo Diesel', 113, 20);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (15, '29/10/2017', 'Felipe', 'A', '�leo Diesel', '169,5', 50);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (16, '29/10/2017', 'Jo�o', 'A', 'Gasolina', '307,699', 70);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (17, '29/10/2017', 'Jo�o', 'B', '�leo Diesel', '216,96', 60);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (18, '29/10/2017', 'Felipe', 'B', 'Gasolina', '87,914', 20);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (19, '29/10/2017', 'Maria', 'A', 'Gasolina', '43,957', 10);
INSERT INTO tb_posto (id, data, funcionario, tank, combustivel, val_din, val_litro) VALUES (20, '29/10/2017', 'Jo�o', 'A', 'Gasolina', '408,8001', 93);

-- Table: tb_taxas
DROP TABLE IF EXISTS tb_taxas;

CREATE TABLE tb_taxas (
    id      INTEGER PRIMARY KEY AUTOINCREMENT
                    UNIQUE
                    NOT NULL,
    imposto DECIMAL NOT NULL,
    val_gas DECIMAL NOT NULL,
    val_die DECIMAL NOT NULL
);

INSERT INTO tb_taxas (id, imposto, val_gas, val_die) VALUES (1, 13, 3.89, 3.2);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
